import SwiftUI

struct Dados: Identifiable {
    let id: Int
    let nome: String
    let descricao: String
}

let dadosArray = [
    Dados(
        id: 1,
        nome: "Introdução",
        descricao: """
        Bem-vindo ao nosso quiz de perguntas e respostas! 🎉
        
        Neste jogo, você poderá testar seus conhecimentos em diversos temas. O objetivo é simples: responder corretamente a 10 perguntas no menor tempo possível.
        
        - Cada pergunta tem 4 alternativas, e apenas uma está correta.
        - A cada acerto, você ganha pontos.
        - Ao final do jogo, sua pontuação será exibida no placar.
        
        Escolha um tema e desafie-se para alcançar o topo! 🚀
        """
    ),
    Dados(
        id: 2,
        nome: "Temas",
        descricao: """
        Aqui você pode escolher o tema do quiz! 🎯
        
        Disponibilizamos vários tópicos, como:
        ✅ História
        ✅ Ciência
        ✅ Cultura pop
        ✅ E muito mais!
        
        A cada nova partida, você pode selecionar um tema diferente, tornando o jogo mais dinâmico e divertido.
        
        💡 Dica: Nas opções, você também pode alterar a dificuldade do jogo para um desafio ainda maior!
        """
    ),
    Dados(
        id: 3,
        nome: "In-game",
        descricao: """
        No jogo, você verá a pergunta e as 4 alternativas.
        
        1️⃣ Escolha a alternativa que acredita ser correta.
        2️⃣ Clique no botão "Confirmar Resposta".
        3️⃣ O jogo indicará se você acertou ou errou:
           - ✅ Acerto: a alternativa ficará com uma borda verde.
           - ❌ Erro: a alternativa errada terá uma borda vermelha, e a correta ficará verde.
        4️⃣ O botão "Próxima Pergunta" será ativado para você seguir no jogo.
        
        💡 Lembre-se: cada acerto soma pontos ao seu placar, e o tempo também conta! Use boas estratégias para maximizar sua pontuação.
        """
    ),
    Dados(
        id: 4,
        nome: "Placar",
        descricao: """
        O placar é atualizado com base nos seus acertos e tempo.
        
        ✔️ Cada resposta correta aumenta sua pontuação.
        ✔️ No final do quiz, sua pontuação total será exibida.
        ✔️ Em breve, você poderá comparar seu desempenho na tela de "Ranking".
        """
    ),
    Dados(
        id: 5,
        nome: "Regras",
        descricao: """
        As regras são simples e diretas:
        
        🎯 Escolha um tema.
        🎯 Responda às perguntas no menor tempo possível.
        🎯 Cada pergunta tem 4 alternativas, e apenas uma resposta correta.
        🎯 Você pode tentar novamente em outros temas ou até no mesmo.
        🎯 A dificuldade escolhida também influencia nos pontos ganhos.
        
        O objetivo é testar seus conhecimentos e se divertir com o jogo! 🚀
        """
    ),
    Dados(
        id: 6,
        nome: "Dicas",
        descricao: """
        Aqui estão algumas dicas para melhorar sua performance no quiz:
        
        🔹 Leia cada pergunta com atenção.
        🔹 Elimine as alternativas que você sabe que estão erradas.
        🔹 Tente responder o mais rápido possível para ganhar mais pontos.
        🔹 Cada tema tem suas peculiaridades, então esteja preparado para perguntas de diferentes áreas!
        
        Boa sorte! 🍀
        """
    )
]


struct TopicoView: View {
    let topico: Dados
    
    var body: some View {
        VStack {
            DisclosureGroup(
                content: {
                    Text(topico.descricao)
                        .font(.custom("Georgia", size: 20))
                        .foregroundColor(Color("DarkBrown"))
                        .padding(.vertical, 10)
                        .padding(.horizontal, 15)
                },
                label: {
                    Text("\(topico.id).   \(topico.nome)")
                        .font(.custom("Futura", size: 30))
                        .foregroundColor(Color("DarkBrown"))
                        .padding(.vertical, 7)
                }
            )
            .padding(.horizontal, 10)
            .background(Color("Cream"))
            .cornerRadius(12.0)
            .padding(.vertical, 7)
        }
    }
}

struct ComoJogar: View {
    var body: some View {
        ZStack {
            Color("LightBrown")
                .ignoresSafeArea()

            ScrollView {
                VStack {
                    Text("Como Jogar")
                        .font(.custom("American Typewriter", size: 37))
                        .fontWeight(.bold)
                        .foregroundColor(Color("DarkBrown"))
                        .shadow(color: .black.opacity(0.6), radius: 10, x: 5, y: 5)
                        .padding(.top, 30)
                        .padding(.bottom, 35)

                    ForEach(dadosArray) { topico in
                        TopicoView(topico: topico)
                    }
                }
                .padding(.horizontal, 20)
            }
        }
        .toolbarBackground(Color("LightBrown"), for: .navigationBar)
    }
}

#Preview {
    ComoJogar().environmentObject(AudioManager()) 
}
