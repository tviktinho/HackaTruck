import SwiftUI

struct Jogar: View {
    @State private var tema: String = ""
    @State private var navegarParaGameView = false
    @AppStorage("dificuldadeEscolhida") private var dificuldade: String = "Normal"

    var body: some View {
        ZStack {
            Color("LightBrown")
                .ignoresSafeArea()

            VStack {
                Text("JOGAR")
                    .font(.custom("American Typewriter", size: 45))
                    .fontWeight(.bold)
                    .foregroundColor(Color("DarkBrown"))
                    .shadow(color: .black.opacity(0.6), radius: 10, x: 5, y: 5)
                    .padding(.top, 20)

                Image(systemName: "questionmark.circle.fill")
                    .font(.system(size: 130))
                    .foregroundColor(Color("DarkBrown"))
                    .padding(.top, 20)

                Spacer()

                VStack {
                    TextField("Digite o tema aqui...", text: $tema)
                        .padding(.vertical, 10)
                        .multilineTextAlignment(.center)
                        .background(Color("Cream"))
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.2), radius: 5, x: 5, y: 5)
                        .padding(.horizontal, 50)
                        .font(.custom("Georgia", size: 20))

                    Text("Sobre o que você quer se desafiar?")
                        .font(.custom("Futura", size: 22))
                        .fontWeight(.bold)
                        .foregroundColor(Color("DarkBrown"))
                        .multilineTextAlignment(.center)

                    Text("Exemplo: Matemática, Português...")
                        .foregroundColor(Color("DarkBrown"))
                        .font(.custom("Georgia", size: 18))
                        .padding(.top, 5)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 30)
                .padding(.bottom, 30)

                Spacer()

                ZStack {
                    Rectangle()
                        .frame(width: 200, height: 60)
                        .foregroundColor(Color("Cream"))
                        .cornerRadius(15)
                        .shadow(color: .black.opacity(0.3), radius: 5, x: 5, y: 5)

                    Button("Começar") {
                        if !tema.isEmpty {
                            navegarParaGameView = true
                        }
                    }
                    .font(.custom("American Typewriter", size: 25))
                    .fontWeight(.bold)
                    .foregroundColor(Color("DarkBrown"))
                    .frame(width: 200, height: 60)
                    .background(Color("Cream"))
                    .cornerRadius(15)
                }
                .padding(.bottom, 40)

                NavigationLink(
                    destination: GameView(tema: tema, dificuldade: dificuldade),
                    isActive: $navegarParaGameView,
                    label: { EmptyView() }
                )
            }
        }
    }
}


#Preview {
    NavigationView {
        Jogar().environmentObject(AudioManager()) 
    }
}
