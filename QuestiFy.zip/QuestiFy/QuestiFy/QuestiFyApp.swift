//
//  QuestiFyApp.swift
//  QuestiFy
//
//  Created by Turma02-5 on 27/02/25.
//

import SwiftUI
import AVFoundation

@main
struct QuestiFyApp: App {
    @StateObject private var audioManager = AudioManager(isSomHabilitado: true)
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(audioManager)
        }
    }
}
