import SwiftUI

struct Opcoes: View {
    @EnvironmentObject var audioManager: AudioManager // Acesso ao AudioManager
    @StateObject private var vm = RankViewModel()
    var temas = ["Claro", "Escuro"]
    @State private var selectedTema = "Claro"
    var dificuldades = ["Difícil", "Normal", "Fácil"]
    @AppStorage("dificuldadeEscolhida") private var selectedDificuldade = "Normal"

    var body: some View {
        ZStack {
            Color("LightBrown")
                .ignoresSafeArea()

            VStack(spacing: 30) {
                Text("Configurações")
                    .font(.custom("American Typewriter", size: 37))
                    .fontWeight(.bold)
                    .foregroundColor(Color("DarkBrown"))
                    .shadow(color: .black.opacity(0.6), radius: 10, x: 5, y: 5)
                    .padding(.top, 30)
                    .padding(.bottom, 20)

                configuracaoPicker(title: "Tema", selection: $selectedTema, options: temas)

                configuracaoPicker(title: "Nível", selection: $selectedDificuldade, options: dificuldades)

                configuracaoToggle(title: "Som", isOn: $audioManager.isSomHabilitado) // Acessa o isSomHabilitado do AudioManager

                ZStack {
                    Rectangle()
                        .fill(Color("Cream"))
                        .frame(height: 70)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                    
                    HStack {
                        Text("Placar")
                            .foregroundColor(Color("DarkBrown"))
                            .font(.custom("Futura", size: 30))
                            .frame(width: 120, alignment: .leading)
                        Button("Redefinir") {
                            
                            if vm.leituraRanking.first != nil {
                                var obj = vm.leituraRanking.first!
                                obj.categoriasRanking = []
                                vm.post(obj)
                            }
                        }
                        .frame(width: 150, height: 40)
                        .accentColor(.black)
                        .background(Color("Beige"))
                        .cornerRadius(8)
                    }
                    .padding(.horizontal, 10)
                }

                
                Spacer()
            }
            .onAppear() {
                vm.fetch()
            }
            .padding(.horizontal, 20)
        }
    }

    func configuracaoPicker(title: String, selection: Binding<String>, options: [String]) -> some View {
        ZStack {
            Rectangle()
                .fill(Color("Cream"))
                .frame(height: 70)
                .cornerRadius(12)
                .shadow(radius: 5)

            HStack {
                Text(title)
                    .foregroundColor(Color("DarkBrown"))
                    .font(.custom("Futura", size: 30))
                    .frame(width: 120, alignment: .leading)

                Picker(title, selection: selection) {
                    ForEach(options, id: \.self) { option in
                        Text(option)
                            .font(.custom("Georgia", size: 1))
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .frame(width: 150, height: 40)
                .accentColor(.black)
                .background(Color("Beige"))
                .cornerRadius(8)
            }
            .padding(.horizontal, 10)
        }
    }

    func configuracaoToggle(title: String, isOn: Binding<Bool>) -> some View {
        ZStack {
            Rectangle()
                .fill(Color("Cream"))
                .frame(height: 70)
                .cornerRadius(12)
                .shadow(radius: 5)

            HStack {
                Text(title)
                    .foregroundColor(Color("DarkBrown"))
                    .font(.custom("Futura", size: 30))
                    .frame(width: 120, alignment: .leading)

                Toggle(isOn: isOn) {
                }
                .toggleStyle(SwitchToggleStyle(tint: Color("DarkBrown")))
                .frame(width: 150, height: 40)
            }
            .padding(.horizontal, 10)
        }
    }
}

#Preview {
    Opcoes()
        .environmentObject(AudioManager()) // Passando o AudioManager para o preview
}
