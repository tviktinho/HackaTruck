import SwiftUI

struct Ranking: View {
    @StateObject var vm = RankViewModel()
    var body: some View {
        ZStack {
            Color("LightBrown")
                .ignoresSafeArea()
            
            VStack {
                ScrollView{
                    Text("Leaderboard")
                        .font(.custom("American Typewriter", size: 45))
                        .fontWeight(.bold)
                        .foregroundColor(Color("DarkBrown"))
                        .shadow(color: .black.opacity(0.5), radius: 5, x: 0, y: 4)
                        .padding(.top, 30)
                    
                    ZStack {
                        Color("Cream")
                            .cornerRadius(20)
                            .shadow(color: .black.opacity(0.3), radius: 10, x: 0, y: 10)
                            .frame(width: 330)
                        
                        VStack(alignment: .leading, spacing: 15) {
                            HStack {
                                Text("Tema")
                                    .font(.custom("Futura", size: 22))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("DarkBrown"))
                                    .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 2)
                                
                                Spacer()
                                
                                Text("Pontos")
                                    .font(.custom("Futura", size: 22))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("DarkBrown"))
                                    .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 2)
                                
                                
                            }                            
                            .padding(.top, 10)
                            
                            ForEach(vm.leituraRanking, id: \.self) { l in
                                ForEach(l.categoriasRanking.sorted(by: { $0.pontuacao > $1.pontuacao }), id: \.self) { leader in
                                    HStack {
                                        Text(leader.tema)
                                            .font(.custom("Georgia", size: 20))
                                            .foregroundColor(Color("DarkBrown"))
                                            .lineLimit(1)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding([.top, .bottom], 5)
                                        
                                        Spacer()
                                        
                                        Text("\(leader.pontuacao)")
                                            .font(.custom("Georgia", size: 20))
                                            .foregroundColor(Color("DarkBrown"))
                                            .padding([.top, .bottom], 5)
                                            .frame(maxWidth: .infinity, alignment: .trailing)
                                    }
                                    .padding(.horizontal, 20)
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.bottom, 10)
                    }
                    .padding([.top, .leading, .trailing], 20)
                    .padding(.bottom, 150)
                }.padding(.horizontal, 20)
            }.onAppear(){
                vm.fetch()
            }
            
        }
    }
}


#Preview {
    Ranking().environmentObject(AudioManager()) 
}
