import Foundation

let apiKey = "AIzaSyDHy1s6gVsZ6888GzrpcGAAjCymqD9LxNU"
let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=\(apiKey)")!


struct Request: Codable {
    let contents: [RequestContent]
}

struct RequestContent: Codable {
    let parts: [Prompt]
}

struct Prompt: Codable {
    let text: String
}

struct GeminiResponse: Codable {
    struct CandidateResponse: Codable {
        let content: ContentResponse
        
        struct ContentResponse : Codable{
            let parts : [Prompt]
        }
    }
    let candidates: [CandidateResponse]
}


struct Pergunta: Codable {
    let pergunta: String
    let respostasErradas: [String]
    let respostaCorreta: String
}

class GeminiQuizViewModel: ObservableObject {
    @Published var perguntas: [Pergunta] = []
    @Published var perguntaAtualIndex: Int = 0
    @Published var arrayAlternativas: [String] = []
    
    var perguntaAtual: Pergunta? {
        guard perguntaAtualIndex < perguntas.count else { return nil }
        return perguntas[perguntaAtualIndex]
    }

    func getResponse(_ prompt: String) {
        let requestBody = Request(contents: [RequestContent(parts: [Prompt(text: prompt)])])
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(requestBody)

        let task = URLSession.shared.dataTask(with: request) { [weak self] data, _, error in
            guard let data = data, error == nil else { return }
            
            do {
                if let decodedResponse = try? JSONDecoder().decode(GeminiResponse.self, from: data) {
                    let jsonString = decodedResponse.candidates.first?.content.parts.first?.text
                    self?.jsonStringDecode(jsonString ?? "")
                }
            }
        }
        task.resume()
    }

    func jsonStringDecode(_ json: String) {
        let jsonString = json
            .replacingOccurrences(of: "`json\n", with: "")
            .replacingOccurrences(of: "\n`\n", with: "")
            .replacingOccurrences(of: "`", with: "")

        if let jsonData = jsonString.data(using: .utf8) {
            do {
                let questions = try JSONDecoder().decode([Pergunta].self, from: jsonData)
                DispatchQueue.main.async {
                    self.perguntas = questions
                    self.perguntaAtualIndex = 0
                    self.carregarAlternativas()
                }
            } catch {
                print("Erro ao decodificar JSON: \(error)")
            }
        }
    }

    func carregarAlternativas() {
        guard let perguntaAtual = perguntaAtual else { return }
        arrayAlternativas = perguntaAtual.respostasErradas + [perguntaAtual.respostaCorreta]
        arrayAlternativas.shuffle()
    }

    func proximaPergunta() {
        if perguntaAtualIndex < perguntas.count - 1 {
            perguntaAtualIndex += 1
            carregarAlternativas()
        }
    }
    
    func prompt(tema: String, dificuldade: String) {
        self.perguntas = []
        self.perguntaAtualIndex = 0
        self.arrayAlternativas = []

        getResponse("Preciso de um array JSON com 10 perguntas e 4 respostas DISTINTAS sobre \(tema) com dificuldade \(dificuldade). Cada pergunta deve conter as chaves: 'pergunta', um array de 3 respostas erradas chamado 'respostasErradas', e a resposta correta em 'respostaCorreta'. As respostas devem ter no máximo 10 palavras. Lembre-se, todas as 4 alternativas devem ser DISTINTAS")
    }

}
