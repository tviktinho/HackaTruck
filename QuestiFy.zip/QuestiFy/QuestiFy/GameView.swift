import SwiftUI
import AVFoundation

struct GameView: View {
    @State private var count: Int = 5
    @StateObject private var viewModel = GeminiQuizViewModel()
    let tema: String
    @State private var selectedAnswer: String?
    @State private var isAnswerConfirmed: Bool = false
    @State private var isCorrectAnswer: Bool? = nil
    @State private var tempoRespostas: [Double] = Array(repeating: 0, count: 10)
    @State private var pontuacoes: [Int] = Array(repeating: 0, count: 10)
    @State private var startTime: Date?
    let dificuldade: String
    @EnvironmentObject var audioManager: AudioManager

    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(Color("LightBrown"))
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    if let pergunta = viewModel.perguntaAtual, count == 0 {
                        Text("Pergunta \(viewModel.perguntaAtualIndex + 1) de \(viewModel.perguntas.count)")
                            .font(.custom("Marker Felt", size: 30))
                            .fontWeight(.bold)
                            .foregroundColor(Color("DarkBrown"))
                            .multilineTextAlignment(.center)

                        Text(pergunta.pergunta)
                            .font(.title)
                            .padding()
                            .foregroundColor(Color("DarkBrown"))
                            .fontWeight(.bold)

                        ForEach(viewModel.arrayAlternativas, id: \.self) { option in
                            Button(action: {
                                audioManager.tocarSomDeBotao()
                                if !isAnswerConfirmed {
                                    selectedAnswer = option
                                }
                            }) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(
                                            isAnswerConfirmed ?
                                                (option == pergunta.respostaCorreta ? Color.green : (option == selectedAnswer ? Color.red : Color.clear))
                                                : Color.clear,
                                            lineWidth: 4
                                        )
                                        .fill(selectedAnswer == option && !isAnswerConfirmed ? Color.darkBrown : Color.cream)
                                        .padding([.leading, .trailing], 16)
                                        .shadow(color: Color.black.opacity(0.8), radius: 5, x: 0, y: 0)

                                    Text(option)
                                        .font(.title2)
                                        .padding()
                                        .foregroundColor(.black)
                                        .multilineTextAlignment(.center)
                                        .frame(maxWidth: .infinity, alignment: .center)
                                }
                            }
                            .buttonStyle(PlainButtonStyle())
                        }

                        if selectedAnswer != nil || isAnswerConfirmed {
                            if !isAnswerConfirmed {
                                Button(action: {
                                    isAnswerConfirmed = true
                                    isCorrectAnswer = (selectedAnswer == pergunta.respostaCorreta)
                                    
                                    if isCorrectAnswer == true {
                                        audioManager.tocarSomDeAcerto()
                                    } else {
                                        audioManager.tocarSomDeErro()
                                    }

                                    if let start = startTime {
                                        let tempoDecorrido = Date().timeIntervalSince(start)
                                        tempoRespostas[viewModel.perguntaAtualIndex] = tempoDecorrido
                                    }
                                    
                                    let pontosGanhos: Int
                                    switch dificuldade {
                                    case "Fácil":
                                        pontosGanhos = 10
                                    case "Normal":
                                        pontosGanhos = 25
                                    case "Difícil":
                                        pontosGanhos = 50
                                    default:
                                        pontosGanhos = 10
                                    }

                                    pontuacoes[viewModel.perguntaAtualIndex] = isCorrectAnswer == true ? pontosGanhos : 0
                                }) {
                                    Text("Confirmar Resposta")
                                        .font(.title2)
                                        .padding()
                                        .foregroundColor(.white)
                                        .background(Color.green)
                                        .cornerRadius(10)
                                }
                                .padding(.top)

                            } else {
                                if viewModel.perguntaAtualIndex < viewModel.perguntas.count - 1 {
                                    Button(action: {
                                        viewModel.proximaPergunta()
                                        selectedAnswer = nil
                                        isAnswerConfirmed = false
                                        isCorrectAnswer = nil
                                        startTime = Date()
                                    }) {
                                        Text("Próxima Pergunta")
                                            .font(.title2)
                                            .padding()
                                            .foregroundColor(.white)
                                            .background(Color.blue)
                                            .cornerRadius(10)
                                    }
                                    .padding(.top)
                                } else {
                                    NavigationLink(destination: FimDeJogo(tempoRespostas: tempoRespostas, pontuacoes: pontuacoes, tema: tema)) {
                                        Text("Finalizar Jogo")
                                            .font(.title2)
                                            .padding()
                                            .foregroundColor(.white)
                                            .background(Color.red)
                                            .cornerRadius(10)
                                    }
                                    .padding(.top)
                                }
                            }
                        }
                    } else {
                        ZStack {
                            Color("LightBrown")
                                .ignoresSafeArea()
                            VStack {
                                Text("Prepare-se")
                                    .font(.custom("American Typewriter", size: 45))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("DarkBrown"))
                                    .shadow(color: .black.opacity(0.6), radius: 10, x: 5, y: 5)

                                Spacer()

                                ZStack {
                                    Circle()
                                        .foregroundColor(Color("DarkBrown"))
                                        .padding(60)
                                    Text("\(count)")
                                        .foregroundColor(Color("LightBrown"))
                                        .font(.system(size: 80))
                                        .bold()
                                }

                                Spacer()
                            }
                        }
                        .onAppear {
                            startCounting()
                        }
                    }
                }
            }
            .padding(.top, 40)
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            viewModel.prompt(tema: tema, dificuldade: dificuldade)
            startTime = Date()
        }
    }

    func startCounting() {
        let interval = 1.0
        for i in (0...5).reversed() {
            DispatchQueue.main.asyncAfter(deadline: .now() + interval * Double(5 - i)) {
                count = i
            }
        }
    }
}


#Preview {
    NavigationView {
        GameView(tema: "Swift", dificuldade: "Normal").environmentObject(AudioManager())
    }
}
