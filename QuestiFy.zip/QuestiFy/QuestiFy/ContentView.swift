//Briza
//Adicionar habilitação/desabilitação de som

//Edilson
//Tela de opcoes
//Tela de fim de jogo
//Adicionar nível no prompt
//Arrumar timer durante o jogo
//Retirar botao de voltar na tela de jogar

//Leandro & Seiti & Paulo
//Ranking ordenado
//Ranking linkado com BD
//Tela de fim de jogo
//Opção de tema claro
//Funcionalidade de redefinir ranking

//EXTRAS
//Imagens no guia?

import SwiftUI

struct ContentView: View {
    @State private var isPressed = false
    @State private var isNavigating = false
    @State private var scale: CGFloat = 1.0
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("LightBrown")
                    .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Text("QUESTIFY")
                        .font(.custom("Marker Felt", size: 65))
                        .foregroundColor(Color("DarkBrown"))
                        .shadow(color: .black.opacity(0.6), radius: 10, x: 5, y: 5)
                        .padding(.top, 70)
                    
                    TimelineView(.animation) { timeline in
                        Image(systemName: "cube.fill")
                            .font(.system(size: 105))
                            .foregroundColor(Color("DarkBrown"))
                            .rotationEffect(.degrees(timeline.date.timeIntervalSince1970 * 40))
                            .scaleEffect(scale)
                            .padding(.top, 15)
                    }
                    
                    Spacer()
                    
                    VStack(spacing: 20) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12.0)
                                .fill(Color("Cream"))
                                .frame(width: 300, height: 60)
                                .shadow(radius: 5)
                            
                            NavigationLink(destination: Jogar()) {
                                Text("Jogar")
                                    .font(.custom("Futura", size: 30))
                                    .foregroundColor(Color("DarkBrown"))
                            }
                            .simultaneousGesture(
                                LongPressGesture(minimumDuration: 0.1)
                                    .onChanged { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = true
                                            self.scale = 1.4
                                        }
                                    }
                                    .onEnded { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = false
                                            self.scale = 1.0
                                        }
                                    }
                            )
                            .simultaneousGesture(
                                TapGesture()
                                    .onEnded {
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isNavigating = true
                                            self.scale = 1.0
                                        }
                                    }
                            )
                        }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 12.0)
                                .fill(Color("Cream"))
                                .frame(width: 300, height: 60)
                                .shadow(radius: 5)
                            
                            NavigationLink(destination: ComoJogar()) {
                                Text("Como Jogar")
                                    .font(.custom("Futura", size: 30))
                                    .foregroundColor(Color("DarkBrown"))
                            }
                            .simultaneousGesture(
                                LongPressGesture(minimumDuration: 0.1)
                                    .onChanged { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = true
                                            self.scale = 1.4
                                        }
                                    }
                                    .onEnded { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = false
                                            self.scale = 1.0
                                        }
                                    }
                            )
                            .simultaneousGesture(
                                TapGesture()
                                    .onEnded {
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isNavigating = true
                                            self.scale = 1.0
                                        }
                                    }
                            )
                        }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 12.0)
                                .fill(Color("Cream"))
                                .frame(width: 300, height: 60)
                                .shadow(radius: 5)
                            
                            NavigationLink(destination: Opcoes()) {
                                Text("Opções")
                                    .font(.custom("Futura", size: 30))
                                    .foregroundColor(Color("DarkBrown"))
                            }
                            .simultaneousGesture(
                                LongPressGesture(minimumDuration: 0.1)
                                    .onChanged { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = true
                                            self.scale = 1.4
                                        }
                                    }
                                    .onEnded { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = false
                                            self.scale = 1.0
                                        }
                                    }
                            )
                            .simultaneousGesture(
                                TapGesture()
                                    .onEnded {
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isNavigating = true
                                            self.scale = 1.0
                                        }
                                    }
                            )
                        }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 12.0)
                                .fill(Color("Cream"))
                                .frame(width: 300, height: 60)
                                .shadow(radius: 5)
                            
                            NavigationLink(destination: Ranking()) {
                                Text("Ranking")
                                    .font(.custom("Futura", size: 30))
                                    .foregroundColor(Color("DarkBrown"))
                            }
                            .simultaneousGesture(
                                LongPressGesture(minimumDuration: 0.1)
                                    .onChanged { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = true
                                            self.scale = 1.4
                                        }
                                    }
                                    .onEnded { _ in
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isPressed = false
                                            self.scale = 1.0
                                        }
                                    }
                            )
                            .simultaneousGesture(
                                TapGesture()
                                    .onEnded {
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            self.isNavigating = true
                                            self.scale = 1.0
                                        }
                                    }
                            )
                        }
                    }
                    .padding(.bottom, 70)
                    Spacer()
                }
                .padding()
            }
        }
        .navigationBarBackButtonHidden(true)
        .tint(Color("DarkBrown"))
    }
}

#Preview {
    ContentView().environmentObject(AudioManager())
}
