
import SwiftUI

struct FimDeJogo: View {
    @State private var navegarParaContentView = false
    @StateObject var vm = RankViewModel()
    let tempoRespostas: [Double]
    let pontuacoes: [Int]
    let tema: String
    var somaTotal: Double {tempoRespostas.reduce(0, +)}
    var totalPontos: Int {
        pontuacoes.reduce(0, +)
    }

    var totalAcertos: Int {
        pontuacoes.filter { $0 != 0}.count
    }

    var pontuacaoFinal: Int {
        var total = 0.0
        for i in 0..<pontuacoes.count {
            let tempo = tempoRespostas[i] + 1
            total += Double(pontuacoes[i]) / tempo
        }
        return Int(total.rounded())
    }
    
    @State var idAux: String = "c0c7dd7afcd335bab7bdd7c7c7f98685"
   // @State var revAux: String = "1-3550689ee16679812c54025ca2ed645e"
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.lightBrown
                    .ignoresSafeArea()
               
                VStack{
                    Text("FIM DE JOGO")
                    .font(.custom("American Typewriter", size: 37))
                    .fontWeight(.bold)
                    .foregroundColor(Color("DarkBrown"))
                    .shadow(color: .black.opacity(0.6), radius: 10, x: 5, y: 5)
                    .padding(.top, 30)
                    .padding(.bottom, 35)
                    Spacer()
                    VStack{
                        HStack{
                            Spacer()
                            Text("\(tema)")
                                .font(.custom("Futura", size: 22))
                                .fontWeight(.bold)
                                .foregroundColor(Color("DarkBrown"))
                                .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 2)
                            Spacer()
                        }
                        HStack{
                            Text("Acertos")
                                .font(.custom("Georgia", size: 20))
                                .foregroundColor(Color("DarkBrown"))
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding([.top, .bottom], 5)
                            Spacer()
                            Text("\(totalAcertos)")
                                .font(.custom("Georgia", size: 20))
                                .foregroundColor(Color("DarkBrown"))
                                .padding([.top, .bottom], 5)
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                        HStack{
                            Text("Pontos")
                                .font(.custom("Georgia", size: 20))
                                .foregroundColor(Color("DarkBrown"))
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding([.top, .bottom], 5)
                            Spacer()
                            Text("\(pontuacaoFinal)")
                                .font(.custom("Georgia", size: 20))
                                .foregroundColor(Color("DarkBrown"))
                                .padding([.top, .bottom], 5)
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                        HStack{
                            Text("Tempo")
                                .font(.custom("Georgia", size: 20))
                                .foregroundColor(Color("DarkBrown"))
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding([.top, .bottom], 5)
                            Spacer()
                            Text(String(format: "%.2f seg", somaTotal))
                                .font(.custom("Georgia", size: 20))
                                .foregroundColor(Color("DarkBrown"))
                                .padding([.top, .bottom], 5)
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                    }
                    .padding()
                    .background(.cream)
                    .cornerRadius(20.0)
                    .padding()
                    .shadow(color: .black.opacity(0.3), radius: 10, x: 0, y: 10)
                    
                    Spacer()
                    
                    
                    Button("Menu Principal") {
                        navegarParaContentView = true
                        
                        var obj = vm.leituraRanking.first!
                        
                      
                        obj.categoriasRanking.append(rankingApi(tema: tema, pontuacao: pontuacaoFinal))
//                        
                        vm.post(obj)
                        
                        
                    }
                    .font(.custom("American Typewriter", size: 25))
                    .fontWeight(.bold)
                    .foregroundColor(Color("DarkBrown"))
                    .frame(width: 200, height: 60)
                    .background(Color("Cream"))
                    .cornerRadius(15)
                    .padding(.bottom, 25)
                    
                    NavigationLink(
                        destination: ContentView(),
                        isActive: $navegarParaContentView,
                        label: { EmptyView() }
                    )
                    
                }.onAppear() {
                    vm.fetch()
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    FimDeJogo(
        tempoRespostas: [2.5, 3.1, 4.2, 1.8, 5.0, 2.9, 3.7, 4.5, 2.2, 3.3],
        pontuacoes: [10, 0, 10, 10, 0, 10, 10, 0, 10, 10],
        tema: "Swift"
    ).environmentObject(AudioManager()) 
}
