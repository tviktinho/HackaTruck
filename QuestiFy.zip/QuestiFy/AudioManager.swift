import AVFoundation
import SwiftUI

class AudioManager: ObservableObject {
    @Published var isSomHabilitado: Bool {
        didSet {
            if isSomHabilitado {
                iniciarSomDeFundo()
            } else {
                pararSomDeFundo()
            }
        }
    }
    
    private var playerFundo: AVAudioPlayer?
    private var playerBotao: AVAudioPlayer?
    private var playerResposta: AVAudioPlayer?
    
    init(isSomHabilitado: Bool = true) {
        self.isSomHabilitado = isSomHabilitado
        if isSomHabilitado {
            iniciarSomDeFundo()
        }
    }
    
    // Função para iniciar o som de fundo
    func iniciarSomDeFundo() {
        guard let url = Bundle.main.url(forResource: "relaxing-loop", withExtension: "mp3") else { return }
        do {
            playerFundo = try AVAudioPlayer(contentsOf: url)
            playerFundo?.numberOfLoops = -1 // Faz o som tocar em loop
            playerFundo?.play()
        } catch {
            print("Erro ao carregar o som de fundo: \(error)")
        }
    }
    
    // Função para parar o som de fundo
    func pararSomDeFundo() {
        playerFundo?.stop()
        playerFundo = nil
    }
    
    // Função para tocar o som do botão
    func tocarSomDeBotao() {
        guard let url = Bundle.main.url(forResource: "click_sound", withExtension: "mp3") else { return }
        do {
            playerBotao = try AVAudioPlayer(contentsOf: url)
            playerBotao?.play()
        } catch {
            print("Erro ao carregar o som do botão: \(error)")
        }
    }
    
    // Função para tocar o som de acerto
    func tocarSomDeAcerto() {
        guard let url = Bundle.main.url(forResource: "correctOption", withExtension: "mp3") else { return }
        do {
            playerResposta = try AVAudioPlayer(contentsOf: url)
            playerResposta?.play()
        } catch {
            print("Erro ao carregar o som de acerto: \(error)")
        }
    }
    
    // Função para tocar o som de erro
    func tocarSomDeErro() {
        guard let url = Bundle.main.url(forResource: "wrongOption", withExtension: "mp3") else { return }
        do {
            playerResposta = try AVAudioPlayer(contentsOf: url)
            playerResposta?.play()
        } catch {
            print("Erro ao carregar o som de erro: \(error)")
        }
    }
}
