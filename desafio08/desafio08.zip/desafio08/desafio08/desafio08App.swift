//
//  desafio08App.swift
//  desafio08
//
//  Created by Turma02-28 on 12/02/25.
//

import SwiftUI

@main
struct desafio08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
