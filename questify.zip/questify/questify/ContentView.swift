import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var player: AVAudioPlayer?
    @State private var clickPlayer: AVAudioPlayer?
    @State private var selectedAnswer: String?
    @State private var feedback: String?
    @State private var isAnswerConfirmed: Bool = false
    
    let question = "Qual a maneira correta de declarar uma constante em Swift?"
    let options = ["let constante = \"Hello World\"",
                   "const constante = \"Hello World\"",
                   "constant constante = \"Hello World\"",
                   "var constante = \"Hello World\""]
    let correctAnswer = "let constante = \"Hello World\""
    
    // Função para iniciar a música de fundo
    func playBackgroundMusic() {
        guard let url = Bundle.main.url(forResource: "relaxing-loop", withExtension: "mp3") else {
            print("Arquivo de música não encontrado.")
            return
        }
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.numberOfLoops = -1 // Faz a música tocar em loop
            player?.play()
        } catch {
            print("Erro ao tentar reproduzir a música: \(error.localizedDescription)")
        }
    }
    
    // Função para tocar o som de clique
    func playClickSound() {
        guard let url = Bundle.main.url(forResource: "click_sound", withExtension: "mp3") else { // Substitua "clickSound" pelo nome do seu arquivo de som de clique
            print("Arquivo de som de clique não encontrado.")
            return
        }
        
        do {
            clickPlayer = try AVAudioPlayer(contentsOf: url)
            clickPlayer?.play()
        } catch {
            print("Erro ao tentar reproduzir o som de clique: \(error.localizedDescription)")
        }
    }
    
    // Função para parar a música de fundo
    func stopBackgroundMusic() {
        player?.stop()
    }
    
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(.lightBrown) // Define a cor de fundo
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text(question)
                    .font(.title)
                    .padding()
                    .foregroundColor(.black)
                    .fontWeight(.bold)
                
                ForEach(options, id: \.self) { option in
                    Button(action: {
                        playClickSound() // Toca o som do clique ao clicar no botão
                        selectedAnswer = option
                        isAnswerConfirmed = false // Reseta o estado do botão de confirmação
                    }) {
                        ZStack {
                            // Sombra aplicada apenas ao fundo do botão
                            RoundedRectangle(cornerRadius: 10)
                                .fill(selectedAnswer == option ? Color.darkBrown : Color.cream)
                                .frame(height: 60)
                                .shadow(color: Color.black.opacity(0.8), radius: 5, x: 0, y: 0)
                            
                            Text(option)
                                .padding()
                                .foregroundColor(.black)
                                //.lineLimit(1) // Garante que o texto não ultrapasse uma linha
                        }
                        //.frame(height: 50) // Definindo uma altura fixa para o botão
                        .padding(.horizontal)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                
                // Botão para confirmar a resposta
                if selectedAnswer != nil {
                    Button(action: {
                        playClickSound()
                        isAnswerConfirmed = true
                        if selectedAnswer == correctAnswer {
                            feedback = "Resposta correta!"
                        } else {
                            feedback = "Resposta incorreta!"
                        }
                    }) {
                        Text("Proxima Pergunta")
                            .font(.title2)
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.green)
                            .cornerRadius(10)
                    }
                    .padding(.top)
                }
                
                if let feedback = feedback {
                    Text(feedback)
                        .font(.headline)
                        .foregroundColor(feedback == "Resposta correta!" ? .green : .red)
                        .padding()
                }
            }
            .zIndex(1.0)
        }
        .foregroundColor(Color.lightBrown)
        .onAppear {
            playBackgroundMusic() // Inicia a música quando a tela aparecer
        }
        .onDisappear {
            stopBackgroundMusic() // Para a música quando a tela desaparecer
        }
    }
}

#Preview {
    ContentView()
}
