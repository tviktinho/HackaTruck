import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var player: AVAudioPlayer?
    @State private var clickPlayer: AVAudioPlayer?
    @State private var feedbackPlayer: AVAudioPlayer? // Player para o som de feedback
    @State private var selectedAnswer: String?
    @State private var feedback: String?
    @State private var isAnswerConfirmed: Bool = false
    @State private var isMusicPlaying: Bool = false
    @State private var isCorrectAnswer: Bool? = nil
    
    let question = "Qual a maneira correta de declarar uma constante constante constante constante constante constante constante em Swift?"
    let options = [
        "let constanteconstanteconstanteconstanteconstanteconstante = \"Hello World\"",
        "const constanteconstanteconstante = \"Hello World\"",
        "constant constanteconstanteconstanteconstanteconstante = \"Hello World\"",
        "var constanteconstanteconstanteconstanteconstanteconstanteconstanteconstanteconstanteconstanteconstanteconstante = \"Hello World\""
    ]
    let correctAnswer = "let constanteconstanteconstanteconstanteconstanteconstante = \"Hello World\""
    
    // Função para iniciar a música de fundo
    func playBackgroundMusic() {
        guard let url = Bundle.main.url(forResource: "relaxing-loop", withExtension: "mp3") else {
            print("Arquivo de música não encontrado.")
            return
        }
        
        do {
            if player == nil {
                player = try AVAudioPlayer(contentsOf: url)
                player?.numberOfLoops = -1 // Faz a música tocar em loop
            }
            player?.play()
        } catch {
            print("Erro ao tentar reproduzir a música: \(error.localizedDescription)")
        }
    }
    
    // Função para tocar o som de clique
    func playClickSound() {
        guard let url = Bundle.main.url(forResource: "click_sound", withExtension: "mp3") else {
            print("Arquivo de som de clique não encontrado.")
            return
        }
        
        do {
            clickPlayer = try AVAudioPlayer(contentsOf: url)
            clickPlayer?.play()
        } catch {
            print("Erro ao tentar reproduzir o som de clique: \(error.localizedDescription)")
        }
    }
    
    // Funções para tocar os sons de acerto e erro
    func playCorrectSound() {
        guard let url = Bundle.main.url(forResource: "correctOption", withExtension: "mp3") else {
            print("Arquivo de som de acerto não encontrado.")
            return
        }
        
        do {
            feedbackPlayer = try AVAudioPlayer(contentsOf: url)
            feedbackPlayer?.play()
        } catch {
            print("Erro ao tentar reproduzir o som de acerto: \(error.localizedDescription)")
        }
    }
    
    func playWrongSound() {
        guard let url = Bundle.main.url(forResource: "wrongOption", withExtension: "mp3") else {
            print("Arquivo de som de erro não encontrado.")
            return
        }
        
        do {
            feedbackPlayer = try AVAudioPlayer(contentsOf: url)
            feedbackPlayer?.play()
        } catch {
            print("Erro ao tentar reproduzir o som de erro: \(error.localizedDescription)")
        }
    }
    
    // Função para parar a música de fundo
    func stopBackgroundMusic() {
        player?.stop()
        player = nil // Liberar a instância do player para evitar sobrecarga de memória
    }

    // Função para alternar entre tocar e parar a música
    func toggleBackgroundMusic() {
        if isMusicPlaying {
            stopBackgroundMusic()
        } else {
            playBackgroundMusic()
        }
        isMusicPlaying.toggle()
    }
    
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(.lightBrown)
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                Text("QUESTIFY")
                    .font(.custom("American Typewriter", size: 45))
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.darkBrown)
                    .shadow(color: .black.opacity(0.6), radius: 10, x:5, y:5)
                    .padding(.bottom, 570)
                Spacer()
            }.zIndex(1.0)
            
            ScrollView {
                VStack(spacing: 20) {
                    
                    Text(question)
                        .font(.title)
                        .padding()
                        .foregroundColor(.darkBrown)
                        .fontWeight(.bold)
                    
                    ForEach(options, id: \.self) { option in
                        Button(action: {
                            playClickSound()
                            selectedAnswer = option
                            isAnswerConfirmed = false
                            isCorrectAnswer = nil
                        }) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(
                                        (isAnswerConfirmed == true) ?
                                            (option == correctAnswer ? Color.green : (option == selectedAnswer ? Color.red : Color.clear)) :
                                            Color.clear,
                                        lineWidth: 4
                                    )
                                    .fill(selectedAnswer == option && isAnswerConfirmed == false ? Color.darkBrown : Color.cream)
                                    .padding([.leading, .trailing], 16)
                                    .shadow(color: Color.black.opacity(0.8), radius: 5, x: 0, y: 0)
                                
                                Text(option)
                                    .padding()
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                                    .frame(maxWidth: .infinity, alignment: .center)
                            }
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    
                    if selectedAnswer != nil {
                        Button(action: {
//                            playClickSound()
                            isAnswerConfirmed = true
                            if selectedAnswer == correctAnswer {
                                feedback = "Resposta correta!"
                                isCorrectAnswer = true
                                playCorrectSound() // Tocar o som de acerto
                            } else {
                                feedback = "Resposta incorreta!"
                                isCorrectAnswer = false
                                playWrongSound() // Tocar o som de erro
                            }
                        }) {
                            Text(isAnswerConfirmed ? "Próxima Pergunta" : "Confirmar Resposta")
                                .font(.title2)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.green)
                                .cornerRadius(10)
                        }
                        .padding(.top)
                    }
                }
            }.padding(.top,70)
            
            VStack {
                HStack {
                    Spacer()
                    Button(action: {
                        toggleBackgroundMusic()
                    }) {
                        Image(systemName: isMusicPlaying ? "speaker.wave.2" : "speaker.slash")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40)
                            .padding(.leading,10)
                            .foregroundColor(.black)
                    }
                    .padding(.top,2)
                    .padding(.trailing, 5)
                }
                Spacer()
            }
        }
        .foregroundColor(Color.lightBrown)
        .onAppear {
            if !isMusicPlaying {
                playBackgroundMusic()
                isMusicPlaying = true
            }
        }
        .onDisappear {
            stopBackgroundMusic()
        }
    }
}

#Preview {
    ContentView()
}
