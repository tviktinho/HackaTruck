//
//  questifyApp.swift
//  questify
//
//  Created by Turma02-28 on 27/02/25.
//

import SwiftUI

@main
struct questifyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            
        }
    }
}
