import Foundation

struct teste{
    var qst : String = " "
    var rs1 : String = " "
    var rs2 : String = " "
    var rs3 : String = " "
    var rs4 : String = " "
}
